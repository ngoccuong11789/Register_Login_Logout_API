//
//  HomeViewController.swift
//  AuthApi
//
//  Created by Nguyen Ngoc Cuong on 10/03/2022.
//

import UIKit

class HomeViewController: UIViewController {

    @IBOutlet weak var listUsersTblView: UITableView!
    @IBOutlet weak var nameLbl: UILabel!
    var strName = ""
    var listUsersVM = ListUsersViewModel()
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        nameLbl.text = strName
        navigationController?.setNavigationBarHidden(false, animated: true)
        listUsersTblView.register(UINib(nibName: CellIdentifier.userCell, bundle: nil), forCellReuseIdentifier: CellIdentifier.userCell)
        listUsersVM.vc = self
        
        listUsersVM.getAllUsreDataAF { [self] result in
            switch result {
            case .success(let listUsers) :
                self.listUsersVM.arrUsers = listUsers as? [ListUsersModel] ?? []
                debugPrint("List User VM : \(self.listUsersVM.arrUsers[0])")
                break
                
            case .failure(let error) :
                debugPrint(error.localizedDescription)
            }
        }
    }
    
    @IBAction func logoutBtnClicked(_ sender: Any) {
        APIManager.shareInstance.callingLogoutAPI()
        
    }
    

}

extension HomeViewController {
    static func shareInstance() -> HomeViewController {
        return instantiateFromStoryboard("Dashboard")
    }
}

extension UIViewController {
    
    class func instantiateFromStoryboard(_ name : String) -> Self {
        return instantiateFromStoryboardHelper(name)
    }
    
    fileprivate class func instantiateFromStoryboardHelper<T>(_ name: String) -> T {
        let storyboard = UIStoryboard(name: name, bundle: nil)
        let controller = storyboard.instantiateViewController(withIdentifier: "\(Self.self)") as! T
        return controller
    }
}

extension HomeViewController: UITableViewDataSource{
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        listUsersVM.arrUsers.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "UserCell", for: indexPath) as? UserCell
        //cell?.modelUser = listUsersVM.arrUsers[indexPath.row]
        cell?.modelUser = listUsersVM.arrUsers[indexPath.row]
        return cell!
    }
}
