//
//  LoginViewController.swift
//  AuthApi
//
//  Created by Nguyen Ngoc Cuong on 09/03/2022.
//

import UIKit

class LoginViewController: UIViewController {
    //MARK: - Outlet
    @IBOutlet weak var txtEmail: UITextField!
    @IBOutlet weak var txtPassword: UITextField!
    
    //MARK:
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        navigationItem.title = "Login"
    }
    
    //MARK: - Event
    @IBAction func signinBtnClicked(_ sender: Any) {
        guard let email = txtEmail.text else { return }
        guard let password = txtPassword.text else { return }
        let loginModel = LoginModel(login: email, password: password)
        
        // func call back userModel or error
        APIManager.shareInstance.callingLoginAPI(login: loginModel) { result in
            switch result {
            case .success(let json) :
                //print(json as AnyObject)
                // don't use "!" to unwrapt
                // don't parse json after callback to viewcontroller
                
                //json as! ResponseLoginModel: unwrapt 3 times?
                let name = (json as! ResponseLoginModel).name
//                let email = (json as! ResponseLoginModel).email
                let userToken = (json as! ResponseLoginModel).userToken
                TokenService.tokenInstance.saveToken(token: userToken)
                let homeVC = HomeViewController.shareInstance()
                homeVC.strName = name
                self.navigationController?.pushViewController(homeVC, animated: true)
                debugPrint("Done")
                
            case .failure(let error) :
                debugPrint(error.localizedDescription)
            }
        }
    }

}

extension LoginViewController {
    static func shareInstance() -> LoginViewController {
        return instantiateFromStoryboard("Main")
    }
}
