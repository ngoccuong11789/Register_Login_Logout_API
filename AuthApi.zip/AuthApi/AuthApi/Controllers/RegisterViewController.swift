//
//  ViewController.swift
//  AuthApi
//
//  Created by Nguyen Ngoc Cuong on 09/03/2022.
//

import UIKit

class RegisterViewController: UIViewController {

    @IBOutlet weak var txtFirstName: UITextField!
    
    @IBOutlet weak var txtLastName: UITextField!
    @IBOutlet weak var txtEmail: UITextField!
    
    @IBOutlet weak var txtPassword: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        navigationItem.title = "Register"
    }
    @IBAction func signinBtnClicked(_ sender: Any) {
        
        let loginVC = self.storyboard?.instantiateViewController(withIdentifier: "LoginViewController") as! LoginViewController

        self.navigationController?.pushViewController(loginVC, animated: true)
        
    }
    
    @IBAction func registerBtnClicked(_ sender: Any) {
        guard let fname = self.txtFirstName.text,
              let lname = self.txtLastName.text,
              let email = self.txtEmail.text,
              let password = self.txtPassword.text else { return  }
        
        let register = RegisterModel(name: fname + lname, email: email, password: password)
        APIManager.shareInstance.callingRegisterAPI(register: register) { isSuccess in
            if isSuccess == true {
                debugPrint("Register Success")
            } else {
                debugPrint("Not Register Success")
            }
        }
        
    }
    
    
}

extension RegisterViewController {
    static func shareInstance() -> RegisterViewController {
        return instantiateFromStoryboard("Main")
    }
}
