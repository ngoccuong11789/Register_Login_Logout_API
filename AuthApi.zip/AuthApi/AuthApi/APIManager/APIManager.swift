//
//  APIManager.swift
//  AuthApi
//
//  Created by Nguyen Ngoc Cuong on 09/03/2022.
//

import Foundation
import Alamofire
import UIKit

enum APIErrors : Error {
    case custom(message : String)
}

typealias Handler = (Swift.Result<Any? , APIErrors>) -> Void

class APIManager {
    
    static let shareInstance = APIManager()
    
    func callingRegisterAPI(register : RegisterModel, completionHandler: @escaping (Bool) -> ()) {
        let headers : HTTPHeaders = [
            .contentType("application/json")
        ]
        
        
        AF.request(register_url, method: .post, parameters: register, encoder: JSONParameterEncoder.default, headers: headers).response { response in
            debugPrint(response)
            switch response.result {
            case .success(let data) :
                do {
                    guard let dataResponse = data else {
                        return
                    }
                    let json = try JSONSerialization.jsonObject(with: dataResponse, options: [])
                    if response.response?.statusCode == 200 {
                        completionHandler(true)
                    } else {
                        completionHandler(false)
                    }
                } catch {
                    print(error.localizedDescription)
                    completionHandler(false)
                }
            case .failure(let error) :
                print(error.localizedDescription)
                completionHandler(false)
            }
        }
        
    }
    
    // Login
    func callingLoginAPI(login: LoginModel, completionHandler: @escaping Handler) {
        //header
        let headers : HTTPHeaders = [
            .contentType("application/json")
        ]
        
        AF.request(login_url, method: .post, parameters: login, encoder: JSONParameterEncoder.default, headers: headers).response { response in
            debugPrint(response)
            switch response.result {
            case .success(let data) :
                do {
                    guard let dataResponse = data else {
                        return
                    }
                    let json = try JSONDecoder().decode(ResponseLoginModel.self, from: dataResponse)
                    
//                    let json = try JSONSerialization.jsonObject(with: dataResponse, options: [])
                    if response.response?.statusCode == 200 {
                        completionHandler(.success(json))
                    } else {
                        completionHandler(.failure(.custom(message: "Please check your network connectivity")))
                    }     
                } catch {
                    debugPrint(error.localizedDescription)
                    completionHandler(.failure(.custom(message: "Please try again")))
                }
            case .failure(let error) :
                debugPrint(error.localizedDescription)
                completionHandler(.failure(.custom(message: "Please try again")))
            }
        }
        
    }
    
    
    // Mark : Logout API
    func callingLogoutAPI() {
        let headers : HTTPHeaders = [
            "user-token" : "\(TokenService.tokenInstance.getToken)"
        ]
        
        AF.request(logout_url, method: .get, headers: headers).response { response in
            switch response.result {
            case .success(let data):
                TokenService.tokenInstance.removetoken()
                
                let rootVC = UIApplication.shared.windows.first?.rootViewController
                if let topVC = UIApplication.getTopViewController() {
                    if rootVC?.children.first is HomeViewController {
                        topVC.navigationController?.pushViewController(RegisterViewController.shareInstance(), animated: true)
                        //topVC.navigationController?.popViewController(animated: true)
                    } else {
                        topVC.navigationController?.popViewController(animated: true)
                    }
                }
                
                break
            case .failure(let error):
                debugPrint(error.localizedDescription)
            }
        }
        
    }
    
    
}
