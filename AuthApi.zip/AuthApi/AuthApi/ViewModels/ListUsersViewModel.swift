//
//  ListUsersViewModel.swift
//  AuthApi
//
//  Created by Nguyen Ngoc Cuong on 11/03/2022.
//

import UIKit
import Alamofire

class ListUsersViewModel{
    
    weak var vc: HomeViewController?
    var arrUsers = [ListUsersModel]()
    // Mark : Get all of User Data
    func getAllUsreDataAF(completionHandler: @escaping Handler){
        AF.request("https://jsonplaceholder.typicode.com/todos/").response { response in
            if let data = response.data {
                do{
                    let userResponse = try JSONDecoder().decode([ListUsersModel].self, from: data)
                    self.arrUsers.append(contentsOf: userResponse)
                    DispatchQueue.main.async{
                        self.vc?.listUsersTblView.reloadData()
                        completionHandler(.success(self.arrUsers))
                    }
                }catch let err{
                    debugPrint(err.localizedDescription)
                    completionHandler(.failure(.custom(message: "Please try again")))
                }
            }
        }
    }
    
}
