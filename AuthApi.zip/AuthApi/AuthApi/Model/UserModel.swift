//
//  UserModel.swift
//  AuthApi
//
//  Created by Nguyen Ngoc Cuong on 10/03/2022.
//

import Foundation
struct UserModel: Encodable {
    let name, email, userToken: String
}
