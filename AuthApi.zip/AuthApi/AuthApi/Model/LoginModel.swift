//
//  LoginModel.swift
//  AuthApi
//
//  Created by Nguyen Ngoc Cuong on 10/03/2022.
//

import Foundation

struct LoginModel : Encodable {
    let login : String
    let password : String
}

struct ResponseLoginModel: Codable {
    let lastLogin: Int
    let userStatus: String
    let created: Int
    let accountType, ownerID, socialAccount: String
    let name, welcomeClass, blUserLocale, userToken: String
    let objectID, email: String

    enum CodingKeys: String, CodingKey {
        case lastLogin, userStatus, created, accountType
        case ownerID = "ownerId"
        case socialAccount, name
        case welcomeClass = "___class"
        case blUserLocale
        case userToken = "user-token"
        case objectID = "objectId"
        case email
    }
}
