//
//  RegisterModel.swift
//  AuthApi
//
//  Created by Nguyen Ngoc Cuong on 09/03/2022.
//

import Foundation

struct RegisterModel: Encodable {
    let name : String
    let email : String
    let password : String
}
