//
//  CellIdentifier.swift
//  AuthApi
//
//  Created by Nguyen Ngoc Cuong on 11/03/2022.
//

import Foundation


struct CellIdentifier {
    // MARK: Cell
    static let userCell = "UserCell"
}
