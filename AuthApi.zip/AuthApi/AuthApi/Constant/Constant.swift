//
//  Constant.swift
//  AuthApi
//
//  Created by Nguyen Ngoc Cuong on 09/03/2022.
//

import Foundation

let app_id = "8556D155-126D-8556-FFF0-0C8E77353F00"
let rest_key = "E75D0FCF-C0E4-4E53-8013-0C464AE03561"
let base_url = "https://api.backendless.com/\(app_id)/\(rest_key)/users/"
let register_url = "\(base_url)register"
let login_url = "\(base_url)login"
let logout_url = "\(base_url)logout"

struct TokenKey {
    static let userLogin = "User_Login_Key"
}
