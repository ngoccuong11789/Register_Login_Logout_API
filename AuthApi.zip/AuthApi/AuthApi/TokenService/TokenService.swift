//
//  TokenService.swift
//  AuthApi
//
//  Created by Nguyen Ngoc Cuong on 10/03/2022.
//

import Foundation

class TokenService {
    
    static let tokenInstance = TokenService()
    let userDefault = UserDefaults.standard
    // Mark : save token
    func saveToken(token : String) {
        userDefault.set(token, forKey: TokenKey.userLogin)
        let token = userDefault.object(forKey: TokenKey.userLogin)
        print("token : \(token)")
    }
    
    // Mark : get Token
    func getToken() -> String {
        if let token = userDefault.object(forKey: TokenKey.userLogin) as? String {
            return token
        } else {
            return ""
        }
    }
    
    // Mark : check token for login
    func checkForLogin() -> Bool {
        if getToken() == "" {
            return false
        } else {
            return true
        }
    }
    
    // Mark : Remove Token
    func removetoken() {
        userDefault.removeObject(forKey: TokenKey.userLogin)
    }
}
